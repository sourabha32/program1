package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.model.Student1;
import com.example.repository.StudentRepository;
import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public Student1 saveStudent(Student1 student) {
        return studentRepository.save(student);
    }

    public Optional<Student1> getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    public Student1 updateStudentAge(Long id, Integer newAge) {
        Optional<Student1> student = studentRepository.findById(id);
        if (student.isPresent()) {
            Student1 existingStudent = student.get();
            existingStudent.setAge(newAge);
            return studentRepository.save(existingStudent);
        }
        return null;
    }

    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }
} 