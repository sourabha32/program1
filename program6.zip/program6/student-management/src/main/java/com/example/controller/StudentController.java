package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.model.Student1;
import com.example.service.StudentService;
import java.util.Optional;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping
    public ResponseEntity<Student1> createStudent(@RequestBody Student1 student) {
        return ResponseEntity.ok(studentService.saveStudent(student));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Student1> getStudent(@PathVariable Long id) {
        Optional<Student1> student = studentService.getStudentById(id);
        return student.map(ResponseEntity::ok)
                     .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/age")
    public ResponseEntity<Student1> updateStudentAge(
            @PathVariable Long id,
            @RequestParam Integer newAge) {
        Student1 updatedStudent = studentService.updateStudentAge(id, newAge);
        return updatedStudent != null ? 
               ResponseEntity.ok(updatedStudent) : 
               ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
        return ResponseEntity.ok().build();
    }
} 