package progarm6.program6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Program6Application {

	public static void main(String[] args) {
		SpringApplication.run(Program6Application.class, args);
	}

}
