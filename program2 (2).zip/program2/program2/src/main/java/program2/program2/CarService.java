package program2.program2;

public interface CarService {
	void startCar();
}
