package program2.program2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Program2Application {

	public static void main(String[] args) {
		SpringApplication.run(Program2Application.class, args);
	}

}
