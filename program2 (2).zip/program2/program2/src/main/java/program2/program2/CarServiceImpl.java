package program2.program2;
import org.springframework.stereotype.Service;

@Service
public class CarServiceImpl implements CarService {

    @Override
    public void startCar() {
        System.out.println("Car is starting...");
    }
}
