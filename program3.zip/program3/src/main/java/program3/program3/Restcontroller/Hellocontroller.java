package program3.program3.Restcontroller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Hellocontroller {

    @GetMapping("/api/hello")
    public String sayHello() {
        return "Hello, World!";
    }
}
