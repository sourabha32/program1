package program3.program3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Program3Application {

	public static void main(String[] args) {
		SpringApplication.run(Program3Application.class, args);
	}

}
