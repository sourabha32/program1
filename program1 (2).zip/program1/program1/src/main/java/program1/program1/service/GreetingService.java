package program1.program1.service;

public interface GreetingService {
	String greet();
}
